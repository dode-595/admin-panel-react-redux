export class ImageUpload{
    
}

